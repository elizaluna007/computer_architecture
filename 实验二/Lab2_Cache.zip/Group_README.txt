./soc_axi_lite_loongson/rtl/myCPU中存放着我们的源代码。
d_cache.v 默认是四路组相联 + 伪LRU + 写回
d_cache_write_back.v 实现的是直接映射+写回
d_cache_2way.v 实现的是二路组相联 + LRU + 写回
d_cache_4way.v实现的是四路组相联 + 伪LRU + 写回