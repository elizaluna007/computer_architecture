# computer_architecture

本实验是在https://github.com/cyyself/step_into_mips的lab_4基础上写成。

##### 初始代码解析

首先观察lab_4给出的指令有哪些：

<img src="代码执行情况.png" style="zoom:50%;" />

可以看出执行两次写操作，并在最后执行写操作，对地址84写入7。

仿真文件如下，当数据地址为84且写入数据为7时结束仿真，控制台打印仿真成功。

<img src="仿真代码.png" style="zoom:50%;" />

<img src="仿真成功.png" style="zoom:50%;" />

1. **（最低要求）实现基于局部历史的分支指令方向预测。PS：要求在报告中给出指令计数**

**器（PC）多路选择器的真值表。**

2. **（较高要求）实现基于全局历史的分支指令方向预测。PS：要求在预测时更新 GHR**

3. **（最高要求）实现竞争的分支指令方向预测。**

4. **（学有余力）实现直接跳转指令的地址预测**

5. **（学有余力）实现间接跳转指令的地址预测**

首先，为了更好地对数据进行探测，先将top.v文件改写为输出值不止clk,rst,writedata,dataaddr和memwrite。

其中，指令mem和数据mem不需修改。

要修改mips.v就得修改datapath.v，hazard.v，最后不要忘记修改testbench文件。

验证一下目前为止没有错：

![](增加指标后的仿真结果_缩短延迟方法.png)

接下来是核心部分，开始修改解决冲突的方法。原本是缩短延迟方法，本实验采用分支预测方法，主要修改的代码就是hazard.v。

原本的hazard.v：

```
`timescale 1ns / 1ps
module hazard(
	//fetch stage
	output wire stallF,
	//decode stage
	input wire[4:0] rsD,rtD,
	input wire branchD,
	output wire forwardaD,forwardbD,
	output wire stallD,
	//execute stage
	input wire[4:0] rsE,rtE,
	input wire[4:0] writeregE,
	input wire regwriteE,
	input wire memtoregE,
	output reg[1:0] forwardaE,forwardbE,
	output wire flushE,
	//mem stage
	input wire[4:0] writeregM,
	input wire regwriteM,
	input wire memtoregM,

	//write back stage
	input wire[4:0] writeregW,
	input wire regwriteW
    );

	wire lwstallD,branchstallD;

	//forwarding sources to D stage (branch equality)
	assign forwardaD = (rsD != 0 & rsD == writeregM & regwriteM);
	assign forwardbD = (rtD != 0 & rtD == writeregM & regwriteM);
	
	//forwarding sources to E stage (ALU)

	always @(*) begin
		forwardaE = 2'b00;
		forwardbE = 2'b00;
		if(rsE != 0) begin
			/* code */
			if(rsE == writeregM & regwriteM) begin
				/* code */
				forwardaE = 2'b10;
			end else if(rsE == writeregW & regwriteW) begin
				/* code */
				forwardaE = 2'b01;
			end
		end
		if(rtE != 0) begin
			/* code */
			if(rtE == writeregM & regwriteM) begin
				/* code */
				forwardbE = 2'b10;
			end else if(rtE == writeregW & regwriteW) begin
				/* code */
				forwardbE = 2'b01;
			end
		end
	end

	//stalls
	assign #1 lwstallD = memtoregE & (rtE == rsD | rtE == rtD);
	assign #1 branchstallD = branchD &
				(regwriteE & 
				(writeregE == rsD | writeregE == rtD) |
				memtoregM &
				(writeregM == rsD | writeregM == rtD));
	assign #1 stallD = lwstallD | branchstallD;
	assign #1 stallF = stallD;
		//stalling D stalls all previous stages
	assign #1 flushE = stallD;
		//stalling D flushes next stage
	// Note: not necessary to stall D stage on store
  	//       if source comes from load;
  	//       instead, another bypass network could
  	//       be added from W to M
endmodule
```

修改后的hazard.v：

```
`timescale 1ns / 1ps
module hazard(
	//fetch stage
	output wire stallF,
	//decode stage
	input wire[4:0] rsD,rtD,
	input wire branchD,
	output wire forwardaD,forwardbD,
	output wire stallD,
	//execute stage
	input wire[4:0] rsE,rtE,
	input wire[4:0] writeregE,
	input wire regwriteE,
	input wire memtoregE,
	output reg[1:0] forwardaE,forwardbE,
	output wire flushE,
	//mem stage
	input wire[4:0] writeregM,
	input wire regwriteM,
	input wire memtoregM,

	//write back stage
	input wire[4:0] writeregW,
	input wire regwriteW,
	
	//新增lwstallD,branchstallD
	output lwstallD,branchstallD
    );

//	wire lwstallD,branchstallD;

	//forwarding sources to D stage (branch equality)
	assign forwardaD = (rsD != 0 & rsD == writeregM & regwriteM);
	assign forwardbD = (rtD != 0 & rtD == writeregM & regwriteM);
	
	//forwarding sources to E stage (ALU)

	always @(*) begin
		forwardaE = 2'b00;
		forwardbE = 2'b00;
		if(rsE != 0) begin
			/* code */
			if(rsE == writeregM & regwriteM & writeregM!=0) begin
				/* code */
				forwardaE = 2'b10;
			end else if(rsE == writeregW & regwriteW & regwriteW!=0) begin
				/* code */
				forwardaE = 2'b01;
			end
		end
		if(rtE != 0) begin
			/* code */
			if(rtE == writeregM & regwriteM & writeregM!=0) begin
				/* code */
				forwardbE = 2'b10;
			end else if(rtE == writeregW & regwriteW & writeregM!=0) begin
				/* code */
				forwardbE = 2'b01;
			end
		end
	end

	//stalls
	assign #1 lwstallD = memtoregE & (rtE == rsD | rtE == rtD);
	assign #1 branchstallD = branchD &
				(regwriteE & 
				(writeregE == rsD | writeregE == rtD) |
				memtoregM &
				(writeregM == rsD | writeregM == rtD));
	assign #1 stallD = lwstallD | branchstallD;
//	assign #1 stallF = stallD;
    assign #1 stallF = lwstallD | branchstallD;
		//stalling D stalls all previous stages
//	assign #1 flushE = stallD;
    assign #1 flushE = lwstallD | branchstallD;
		//stalling D flushes next stage
	// Note: not necessary to stall D stage on store
  	//       if source comes from load;
  	//       instead, another bypass network could
  	//       be added from W to M
endmodule

```

验证一下仿真结果：

![](修改解决hazard方法后仿真结果.png)